const express = require('express');
const transactionController = require('../controllers/transactionController');
const authMiddleware = require('../middlewares/authMiddleware');
const router = express.Router();

router.post('/', authMiddleware, transactionController.addTransaction);
router.get('/', authMiddleware, transactionController.getTransactions);

module.exports = router;
