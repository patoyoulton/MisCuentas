import React, { useState, useContext } from 'react';
import transactionService from '../services/transactionService';
import { AuthContext } from '../context/AuthContext';

const TransactionForm = ({ onAddTransaction, accounts }) => {
  const { user } = useContext(AuthContext);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [type, setType] = useState('expense');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState('');
  const [currency, setCurrency] = useState('CLP');
  const [accountId, setAccountId] = useState(accounts.length ? accounts[0].id : '');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const transaction = {
      amount: parseFloat(amount),
      note,
      type,
      category,
      date,
      currency,
      userId: user.id,
      accountId
    };

    try {
      await transactionService.addTransaction(transaction);
      onAddTransaction(transaction);
      setAmount('');
      setNote('');
      setType('expense');
      setCategory('');
      setDate('');
      setCurrency('CLP');
      setAccountId(accounts.length ? accounts[0].id : '');
    } catch (error) {
      console.error('Error adding transaction:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="container mt-5">
      <div className="form-group">
        <label>Monto</label>
        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="form-control" required />
      </div>
      <div className="form-group">
        <label>Nota</label>
        <input type="text" value={note} onChange={(e) => setNote(e.target.value)} className="form-control" required />
      </div>
      <div className="form-group">
        <label>Tipo</label>
        <select value={type} onChange={(e) => setType(e.target.value)} className="form-control" required>
          <option value="expense">Gasto</option>
          <option value="income">Ingreso</option>
        </select>
      </div>
      <div className="form-group">
        <label>Categoría</label>
        <input type="text" value={category} onChange={(e) => setCategory(e.target.value)} className="form-control" required />
      </div>
      <div className="form-group">
        <label>Fecha</label>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="form-control" required />
      </div>
      <div className="form-group">
        <label>Moneda</label>
        <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="form-control" required>
          <option value="CLP">CLP</option>
          <option value="USD">USD</option>
        </select>
      </div>
      <div className="form-group">
        <label>Cuenta</label>
        <select value={accountId} onChange={(e) => setAccountId(e.target.value)} className="form-control" required>
          {accounts.map(account => (
            <option key={account.id} value={account.id}>{account.name}</option>
          ))}
        </select>
      </div>
      <button type="submit" className="btn btn-primary btn-block mt-3">Agregar Transacción</button>
    </form>
  );
};

export default TransactionForm;
