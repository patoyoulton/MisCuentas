import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../context/AuthContext';
import transactionService from '../services/transactionService';
import accountService from '../services/accountService';
import TransactionForm from './TransactionForm';
import { Button, Modal } from 'react-bootstrap';

const Dashboard = () => {
  const { user } = useContext(AuthContext);
  const [transactions, setTransactions] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [balance, setBalance] = useState(0);
  const [filter, setFilter] = useState({ month: '', year: '' });
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    const fetchTransactions = async () => {
      const data = await transactionService.getTransactions();
      setTransactions(data);
    };

    const fetchAccounts = async () => {
      const data = await accountService.getAccounts();
      setAccounts(data);
    };

    fetchTransactions();
    fetchAccounts();
  }, []);

  useEffect(() => {
    const calculateBalance = () => {
      let total = accounts.reduce((acc, account) => acc + account.currentBalance, 0);
      setBalance(total);
    };

    calculateBalance();
  }, [accounts]);

  const handleAddTransaction = (newTransaction) => {
    setTransactions([...transactions, newTransaction]);
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilter({ ...filter, [name]: value });
  };

  const filteredTransactions = transactions.filter(transaction => {
    const transactionDate = new Date(transaction.date);
    return (!filter.month || transactionDate.getMonth() + 1 === parseInt(filter.month)) &&
           (!filter.year || transactionDate.getFullYear() === parseInt(filter.year)) &&
           (!selectedAccount || transaction.accountId === selectedAccount.id);
  });

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Dashboard</h2>
      <p>Bienvenido, {user.username}</p>
      <div className="row mb-4">
        <div className="col-md-4">
          <div className="card text-white bg-primary mb-3">
            <div className="card-body">
              <h5 className="card-title">Balance Actual</h5>
              <p className="card-text">${balance}</p>
            </div>
          </div>
        </div>
        {accounts.map(account => (
          <div className="col-md-4" key={account.id}>
            <div className="card text-white bg-secondary mb-3">
              <div className="card-body">
                <h5 className="card-title">{account.name}</h5>
                <p className="card-text">{account.bank} - ${account.currentBalance} {account.currency}</p>
                <button className="btn btn-light" onClick={() => setSelectedAccount(account)}>Ver Transacciones</button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mb-4">
        <Button variant="primary" onClick={() => setShowModal(true)}>Agregar Transacción</Button>
      </div>
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Agregar Transacción</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <TransactionForm onAddTransaction={handleAddTransaction} accounts={accounts} />
        </Modal.Body>
      </Modal>
      <div className="mb-4">
        <h3>Filtrar Transacciones</h3>
        <form className="form-inline">
          <div className="form-group mr-2">
            <label className="mr-2">Mes</label>
            <select name="month" value={filter.month} onChange={handleFilterChange} className="form-control">
              <option value="">Todos</option>
              <option value="1">Enero</option>
              <option value="2">Febrero</option>
              <option value="3">Marzo</option>
              <option value="4">Abril</option>
              <option value="5">Mayo</option>
              <option value="6">Junio</option>
              <option value="7">Julio</option>
              <option value="8">Agosto</option>
              <option value="9">Septiembre</option>
              <option value="10">Octubre</option>
              <option value="11">Noviembre</option>
              <option value="12">Diciembre</option>
            </select>
          </div>
          <div className="form-group mr-2">
            <label className="mr-2">Año</label>
            <input type="number" name="year" value={filter.year} onChange={handleFilterChange} className="form-control" />
          </div>
        </form>
      </div>
      <div className="mb-4">
        <h3>Transacciones Recientes</h3>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Nota</th>
              <th>Tipo</th>
              <th>Categoría</th>
              <th>Monto</th>
              <th>Cuenta</th>
            </tr>
          </thead>
          <tbody>
            {filteredTransactions.map(transaction => (
              <tr key={transaction.id}>
                <td>{transaction.date}</td>
                <td>{transaction.note}</td>
                <td>{transaction.type}</td>
                <td>{transaction.category}</td>
                <td>${transaction.amount}</td>
                <td>{accounts.find(acc => acc.id === transaction.accountId)?.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
