import React from 'react';

const Reports = () => {
  return (
    <div>
      <h2>Reportes</h2>
      <p>Aquí se mostrarán los reportes financieros.</p>
    </div>
  );
};

export default Reports;
