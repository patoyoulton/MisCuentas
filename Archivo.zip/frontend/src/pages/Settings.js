import React, { useState, useEffect, useContext } from 'react';
import accountService from '../services/accountService';
import { AuthContext } from '../context/AuthContext';
import { Tabs, Tab } from 'react-bootstrap';

const Settings = () => {
  const { user } = useContext(AuthContext);
  const [accounts, setAccounts] = useState([]);
  const [accountName, setAccountName] = useState('');
  const [accountType, setAccountType] = useState('');
  const [initialBalance, setInitialBalance] = useState('');
  const [currency, setCurrency] = useState('CLP');
  const [bank, setBank] = useState('');

  useEffect(() => {
    const fetchAccounts = async () => {
      if (user) {
        const data = await accountService.getAccounts(user.id);
        setAccounts(data);
      }
    };
    fetchAccounts();
  }, [user]);

  const handleAddAccount = async (e) => {
    e.preventDefault();
    const newAccount = {
      userId: user.id,
      name: accountName,
      type: accountType,
      initialBalance: parseFloat(initialBalance),
      currency,
      bank
    };
    try {
      await accountService.addAccount(newAccount);
      setAccounts([...accounts, newAccount]);
      setAccountName('');
      setAccountType('');
      setInitialBalance('');
      setCurrency('CLP');
      setBank('');
    } catch (error) {
      console.error('Error adding account:', error);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Configuración</h2>
      <Tabs defaultActiveKey="user" id="settings-tabs">
        <Tab eventKey="user" title="Información Personal">
          <div className="card mt-4">
            <div className="card-body">
              <h5 className="card-title">Información Personal</h5>
              <p>Nombre de Usuario: {user?.username}</p>
              <p>Email: {user?.email}</p>
            </div>
          </div>
        </Tab>
        <Tab eventKey="accounts" title="Cuentas">
          <div className="card mt-4">
            <div className="card-body">
              <h5 className="card-title">Configuración de Cuentas</h5>
              <form onSubmit={handleAddAccount}>
                <div className="form-group">
                  <label>Nombre de la Cuenta</label>
                  <input type="text" value={accountName} onChange={(e) => setAccountName(e.target.value)} className="form-control" required />
                </div>
                <div className="form-group">
                  <label>Tipo de Cuenta</label>
                  <input type="text" value={accountType} onChange={(e) => setAccountType(e.target.value)} className="form-control" required />
                </div>
                <div className="form-group">
                  <label>Saldo Inicial</label>
                  <input type="number" value={initialBalance} onChange={(e) => setInitialBalance(e.target.value)} className="form-control" required />
                </div>
                <div className="form-group">
                  <label>Moneda</label>
                  <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="form-control" required>
                    <option value="CLP">CLP</option>
                    <option value="USD">USD</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Banco</label>
                  <input type="text" value={bank} onChange={(e) => setBank(e.target.value)} className="form-control" required />
                </div>
                <button type="submit" className="btn btn-primary btn-block mt-3">Agregar Cuenta</button>
              </form>
              <div className="mt-5">
                <h3>Cuentas Existentes</h3>
                <ul className="list-group">
                  {accounts.map(account => (
                    <li key={account.id} className="list-group-item">
                      {account.name} - {account.type} - {account.bank} - ${account.initialBalance} {account.currency}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </Tab>
      </Tabs>
    </div>
  );
};

export default Settings;
